<div class="hero" id="home">
      <div class="hero-container">
        <h1 class="hero-heading">
          Pampered Puppies
        </h1>
        <span>by Emmy</span>
      </div>
    </div>