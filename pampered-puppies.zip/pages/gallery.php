<?php 
$dir = 'images/gallery/';
$images_array = glob($dir.'*.jpg');
?>

<div class="gallery" id="gallery">
      <h3>Gallery</h3>
      <div class="slide-container swiper">
        <div class="slide-content">
          <div class="card-wrapper swiper-wrapper">
          <?php foreach($images_array as $image): ?>
            <div class="card swiper-slide">
              <div class="image-content">
                <div class="card-image">
                  <img src="<?=$image?>" alt="Pampered Puppies" class="card-img" loading="lazy" />
                </div>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
        <div class="swiper-button-next swiper-navBtn"></div>
        <div class="swiper-button-prev swiper-navBtn"></div>
        <div class="swiper-pagination"></div>
      </div>
    </div>
   