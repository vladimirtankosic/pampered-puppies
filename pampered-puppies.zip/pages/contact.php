<div class="contact-main" id="contact">
      <h3>Contact Us</h3>
      <div class="contact-main-container">
        <div class="contact-us">
          <ul>
            <li class="phone">
              <a href="tel:+381631830917">+381631830917</a>
            </li>
            <li class="phone">
              <a href="tel:+393249044397">+393249044397</a>
            </li>
            <li class="mail">
              <a href="mailto:emiperic@gmail.com">emiperic@gmail.com</a>
            </li>
          </ul>
          <div class="contact-social-media">
              <p>Follow Us</p>
              <div class="contact-social-icons">
                <a href="https://www.facebook.com/people/Teneri-Cuccioli/100078131924584/" class="social-icon-link" target="_blank"><i class="fab fa-facebook"></i></a>
                <a href="https://www.instagram.com/pampered_puppies_by_emmy/?igshid=MzRlODBiNWFlZA%3D%3D" class="social-icon-link" target="_blank"><i class="fab fa-instagram"></i></a>
                <a href="https://www.tiktok.com/@pamperedpuppiesbyemmy?_t=8gjEf439iqn&_r=1" class="social-icon-link" target="_blank"><i class="fab fa-tiktok"></i></a>
              </div>
            </div>
        </div>

        <div class="contact-main-img-container">
          <div class="contact-main-img-card">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d11364.12964721326!2d20.6046038!3d44.5963625!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4750a19dad769e89%3A0xef0574c7d2c3c33c!2z0JzQsNC70LAg0JjQstCw0L3Rh9Cw!5e0!3m2!1ssr!2srs!4v1666852718513!5m2!1ssr!2srs"
              width="240"
              height="240"
              style="border-radius: 10px"
              allowfullscreen=""
              loading="lazy"
              referrerpolicy="no-referrer-when-downgrade"
            ></iframe>
            <li class="adress">
              <a href="https://goo.gl/maps/r9N1xbjp6DaRN9rz7" target="_blank"
                >Put za Plandiste 2 deo, 41 Mala Ivanca, Srbija</a
              >
            </li>
          </div>
        </div>
        <div class="contact-main-img-container">
          <div class="contact-main-img-card">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2793.311471433872!2d11.372193399999999!3d45.564174699999995!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x477f49875eafcb6d%3A0xf4b1beadd6ad2228!2zUGlhenphIEcuIE1henppbmksIDM2MDcwIFRyaXNzaW5vIFZJLCDQmNGC0LDQu9C40ZjQsA!5e0!3m2!1ssr!2srs!4v1666852563436!5m2!1ssr!2srs"
              width="240"
              height="240"
              style="border-radius: 10px"
              allowfullscreen=""
              loading="lazy"
              referrerpolicy="no-referrer-when-downgrade"
            ></iframe>

            <li class="adress">
              <a href="https://goo.gl/maps/GvCoXeSbaoyWRMkEA" target="_blank"
                >Piazza G. Mazzini, Trissino, Vicenza, Italia</a
              >
            </li>
          </div>
        </div>
      </div>
    </div>