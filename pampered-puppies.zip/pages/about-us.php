<div class="main" id="about">
      <div class="main-container">
          <h2>About Us</h2>
          <p>Our breeding is not only born from the love for dogs, but from our desire to make them unique and special every day. Our is a big family based on unconditional love. We have worked so much in the selection of healthy breeding dogs, which have various titles, clean genetic tests and with due visits to the patella, of course with negative results. Our puppies are born and grow in the house loved and pumpered by the whole family, and our biggest aim is to make happy and confident the new owners who rely on us.</p>
      </div>
</div>