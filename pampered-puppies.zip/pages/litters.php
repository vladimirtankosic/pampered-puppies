<?php 
$collaborazione_1 = 'images/litters/collaborazione-1/';
$collaborazione_arr_1 = glob($collaborazione_1.'*.jpg');

$red_toy_1 = 'images/litters/red-toy-1/';
$red_toy_arr_1 = glob($red_toy_1.'*.jpg');

$black_tan_1 = 'images/litters/black-and-tan-1/';
$black_tan_arr_1 = glob($black_tan_1.'*.jpg');

$chocolat_1 = 'images/litters/chocolat-1/';
$chocolat_arr_1 = glob($chocolat_1.'*.jpg');
?>
<div id="litters" class="wrapper">

	<h3>Our litters</h1>

	<p>Toy and Miniature poodle puppies available, Black Tan, Chocolat Tan, Chocolat and Red colours. For more information and availability, please contact us.</p>

	<p>Explore the magical world of our dog breeding kennel! Click to the right to discover more about our adorable puppies, their origins, and the tender care we provide. Your perfect four-legged friend may be just one click away! Get to know your future family member today.</p>

	<div class="methodslist">

			<div class="method">
			<p>Chocolat &Tan</p>
			<i class="icon-help fa fa-chevron-down"></i>
				<div class="details">
					<div class="wrapper">
						<div class="slideshow-container">
							<?php foreach($chocolat_arr_1 as $chocolat1): ?>
								<div class="litters-img mySlides1 fade">
									<img src="<?=$chocolat1?>" alt="Pampered Puppies" loading="lazy">
								</div>
							<?php endforeach; ?>
							<a class="prev" onclick="plusSlides1(-1)">❮</a>
							<a class="next" onclick="plusSlides1(1)">❯</a>
						</div>
					</div>
						<p>Puppies born on 09/10/2023 from our verified breeders Fantasia Izjuminkoi Juliany & Ori-Diamond: this beautiful litter of two masccheti and a chocolat female is born. A phantom chocolate mask.</p>
				</div>
			</div>

			<div class="method">
			<p>Black & Tan</p>
			<i class="icon-help fa fa-chevron-down"></i>
				<div class="details">
					<div class="wrapper">
						<div class="slideshow-container">
							<?php foreach($black_tan_arr_1 as $black_tan1): ?>
								<div class="litters-img mySlides2 fade">
									<img src="<?=$black_tan1?>" alt="Pampered Puppies" loading="lazy">
								</div>
							<?php endforeach; ?>
							<a class="prev" onclick="plusSlides2(-1)">❮</a>
							<a class="next" onclick="plusSlides2(1)">❯</a>
						</div>
					</div>
						<p>Puppies born on 08/27/2023, from champion parents of Russia, genetically tested for degenerative diseases, patella gradus 0/0</p>
				</div>
			</div>

			<div class="method">
			<p>Red Toy Poodles</p>
			<i class="icon-help fa fa-chevron-down"></i>
				<div class="details">
					<div class="wrapper">
						<div class="slideshow-container">
							<?php foreach($red_toy_arr_1 as $red_toy1): ?>
								<div class="litters-img mySlides3 fade">
									<img src="<?=$red_toy1?>" alt="Pampered Puppies" loading="lazy">
								</div>
							<?php endforeach; ?>
							<a class="prev" onclick="plusSlides3(-1)">❮</a>
							<a class="next" onclick="plusSlides3(1)">❯</a>
						</div>
					</div>
						<p>From our young mare Lorena and in an external stud with Amarok Moonlight Tango brown in red, on 08/11/23 beautiful males were born, two red and one black and a red female.</p>
				</div>
			</div>

			<div class="method">
			<p>Dalla collaborazione esterna</p>
			<i class="icon-help fa fa-chevron-down"></i>
				<div class="details">
					<div class="wrapper">
						<div class="slideshow-container">
							<?php foreach($collaborazione_arr_1 as $collaborazione1): ?>
								<div class="litters-img mySlides4 fade">
									<img src="<?=$collaborazione1?>" alt="Pampered Puppies" loading="lazy">
								</div>
							<?php endforeach; ?>
							<a class="prev" onclick="plusSlides4(-1)">❮</a>
							<a class="next" onclick="plusSlides4(1)">❯</a>
						</div>
					</div>
						<p>From the external collaboration the two beautiful little brothers born on 06/27/2023 to mother Black&Tan and father Merle. They have Alianz pedigree.</p>
				</div>
			</div>

	</div>
</div>
