<nav class="navbar">
      <div class="navbar-container">
        <a href="#home" id="navbar-logo"><img src="images/logo/logo-red.svg" alt="Pampered Puppies" loading="lazy"></a>
        <div class="navbar-toggle" id="mobile-menu">
          <span class="bar"></span>
          <span class="bar"></span>
          <span class="bar"></span>
        </div>
        <ul id="mainNav" class="navbar-menu">
          <li class="navbar-item">
            <a href="#home" class="active navbar-links">Home</a>
          </li>
          <li class="navbar-item">
            <a href="#about" class="navbar-links">About</a>
          </li>
          <li class="navbar-item">
            <a href="#litters" class="navbar-links">Our Litters</a>
          </li>
          <li class="navbar-item">
            <a href="#parents" class="navbar-links">Parents</a>
          </li>
          <li class="navbar-item">
            <a href="#gallery" class="navbar-links">Gallery</a>
          </li>
          <li class="navbar-item">
            <a href="#contact" class="navbar-links">Contact</a>
          </li>
        </ul>
      </div>
    </nav>