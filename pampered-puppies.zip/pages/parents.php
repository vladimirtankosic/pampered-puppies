
<div id="parents" class="tab-main-container">
        <h2>Parents of Puppies</h2>
        <div class="tab-nav-bar">
            <div class="tab-navigation">
                <i class="uil uil-angle-left left-btn"></i>
                <i class="uil uil-angle-right right-btn"></i>

                <ul class="tab-menu">
                    <li class="tab-btn fm active">Tavolga</li>
                    <li class="tab-btn fm">Fantasia</li>
                    <li class="tab-btn fm">Lorena</li>
                    <li class="tab-btn">Ori</li>
                    <li class="tab-btn">Nevil</li>
                </ul>
            </div>
        </div>
        <div class="tab-content">
            <div class="tab active">
                <div class="row">
                    <div class="left-column">
                        <div class="img-card">
                            <img src="images/dogs/tavolga.jpg" alt="Pampered Puppies" loading="lazy">
                        </div>
                    </div>
                    <div class="right-column">
                        <div class="info">
                            <h2 class="city">Gently Born Tavolga</h2>
                            <div class="description">
                            <p>Female</p>
                                <ul>
                                    <p>Genetically tested parents:</p>
                                    <li>DM Degenerative myelopathy</li>
                                    <li>Neonatal encephalopathy with seizures </li>
                                    <li>prcd-PRA </li>
                                    <li>rcd4-PRA</li>
                                    <li>vWD 1</li>
                                    <li>CDDY IVDD</li>
                                    <li>Combination coat colours dog</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="tab">
                <div class="row">
                    <div class="left-column">
                        <div class="img-card">
                            <img src="images/dogs/fantasia.jpg" alt="Pampered Puppies" loading="lazy">
                        </div>
                    </div>
                    <div class="right-column">
                        <div class="info">
                            <h2 class="city">Fantasia Izjuminkoi Juliany</h2>
                            <div class="description">
                            <p>Female</p>
                                <ul>
                                    <p>Genetically tested parents:</p>
                                    <li>DM Degenerative myelopathy</li>
                                    <li>Neonatal encephalopathy with seizures </li>
                                    <li>prcd-PRA </li>
                                    <li>rcd4-PRA</li>
                                    <li>vWD 1</li>
                                    <li>CDDY IVDD</li>
                                    <li>Combination coat colours dog</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="tab">
                <div class="row">
                    <div class="left-column">
                        <div class="img-card">
                            <img src="images/dogs/lorena.jpg" alt="Pampered Puppies" loading="lazy">
                        </div>
                    </div>
                    <div class="right-column">
                        <div class="info">
                            <h2 class="city">Lorena</h2>
                            <div class="description">
                            <p>Female</p>
                                <ul>
                                    <p>Genetically tested parents:</p>
                                    <li>DM Degenerative myelopathy</li>
                                    <li>Neonatal encephalopathy with seizures </li>
                                    <li>prcd-PRA </li>
                                    <li>rcd4-PRA</li>
                                    <li>vWD 1</li>
                                    <li>CDDY IVDD</li>
                                    <li>Combination coat colours dog</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="tab">
                <div class="row">
                    <div class="left-column">
                        <div class="img-card">
                            <img src="images/dogs/ori.jpg" alt="Pampered Puppies" loading="lazy">
                        </div>
                    </div>
                    <div class="right-column">
                        <div class="info">
                            <h2 class="city">Ori-Diamond</h2>
                            <div class="description">
                            <p>Male</p>
                                <ul>
                                    <p>Genetically tested parents:</p>
                                    <li>DM Degenerative myelopathy</li>
                                    <li>Neonatal encephalopathy with seizures </li>
                                    <li>prcd-PRA </li>
                                    <li>rcd4-PRA</li>
                                    <li>vWD 1</li>
                                    <li>CDDY IVDD</li>
                                    <li>Combination coat colours dog</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab">
                <div class="row">
                    <div class="left-column">
                        <div class="img-card">
                            <img src="images/dogs/nevil.jpg" alt="Pampered Puppies" loading="lazy">
                        </div>
                    </div>
                    <div class="right-column">
                        <div class="info">
                            <h2 class="city">Gently Born Nevil</h2>
                            <div class="description">
                            <p>Male</p>
                                <ul>
                                <p>Genetically tested parents:</p>
                                    <li>DM Degenerative myelopathy</li>
                                    <li>Neonatal encephalopathy with seizures </li>
                                    <li>prcd-PRA </li>
                                    <li>rcd4-PRA</li>
                                    <li>vWD 1</li>
                                    <li>CDDY IVDD</li>
                                    <li>Combination coat colours dog</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
</div>