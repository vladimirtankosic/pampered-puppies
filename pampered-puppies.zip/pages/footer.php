<div class="footer-container">
  <p class="website-rights">
          © Pampered Puppies 2023 <br>
          All rights reserved</p>
</div>
<i id="backtotop" class="fa fa-arrow-up"></i>