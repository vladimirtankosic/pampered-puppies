<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Get your perfect Toy Poodle today! Meet the sweetest and most intelligent four-legged friends. Find information about breeding pairs, available puppies, and care tips. We're ready to help you find the ideal pet. Buy your Toy Poodle now and bring joy to your home!">
    <title>Pampered Puppies by Emmy</title>
    <link rel="stylesheet" href="css/main-min.css" />
    <link rel="stylesheet" href="css/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="images/logo/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="images/logo/favicons/favicon-16x16.png">
    <link rel="manifest" href="images/logo/favicons/site.webmanifest">
    <link rel="mask-icon" href="images/logo/favicons/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
    <script
      src="https://kit.fontawesome.com/9b27542e89.js"
      crossorigin="anonymous"
    ></script>
  </head>