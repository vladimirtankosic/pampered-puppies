//Menu
const menu = document.querySelector("#mobile-menu");
const menuLinks = document.querySelector(".navbar-menu");
const navlogo = document.querySelector("#navbar-logo");

// Display Mobile Menu
const mobileMenu = () => {
  menu.classList.toggle("is-active");
  menuLinks.classList.toggle("active");
};

menu.addEventListener("click", mobileMenu);

// Close Mobile Menu
const hideMobileMenu = () => {
  const menuBars = document.querySelector(".is-active");
  if (window.innerWidth <= 768 && menuBars) {
    menu.classList.toggle("is-active");
    menuLinks.classList.remove("active");
  }
};

menuLinks.addEventListener("click", hideMobileMenu);
navlogo.addEventListener("click", hideMobileMenu);

//scroll to top
const backtotop = document.getElementById('backtotop')
document.addEventListener('scroll', () => {
	let vpos = window.pageYOffset || document.documentElement.scrollTop;
	if (vpos > 1000) {
		backtotop.classList.add('show')
	} else {
		backtotop.classList.remove('show')
	}
});
backtotop.addEventListener('click', (e) => {
	e.preventDefault()
	window.scrollTo({
	    "behavior": "smooth",
	    "right": 0,
	    "top": 0
	})
})


//Swiper
var swiper = new Swiper(".slide-content", {
  slidesPerView: 3,
  spaceBetween: 25,
  loop: true,
  autoplay: {
    delay: 2000
  },
  centerSlide: "true",
  fade: "true",
  grabCursor: "true",
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
    dynamicBullets: true,
  },
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
  },

  breakpoints: {
    0: {
      slidesPerView: 1,
    },
    600: {
      slidesPerView: 2,
    },
    950: {
      slidesPerView: 3,
    },
  },
});

//TABS

const btnLeft = document.querySelector(".left-btn");
const btnRight = document.querySelector(".right-btn");
const tabMenu = document.querySelector(".tab-menu");

const IconVisibility = () => {
    let scrollLeftValue = Math.ceil(tabMenu.scrollLeft);
    let scrollableWidth = tabMenu.scrollWidth - tabMenu.clientWidth;
    
    btnLeft.style.display = scrollLeftValue > 0 ? "block" : "none";
    btnRight.style.display = scrollableWidth > scrollLeftValue ? "block" : "none";
}

btnRight.addEventListener("click", () => {
    tabMenu.scrollLeft += 150;
    setTimeout(() => IconVisibility(), 50);
});

btnLeft.addEventListener("click", () => {
    tabMenu.scrollLeft -= 150;
    setTimeout(() => IconVisibility(), 50);
});

window.onload = function () {
    btnRight.style.display = tabMenu.scrollWidth > tabMenu.clientWidth || tabMenu.scrollWidth >= window.innerWidth ? "block" : "none";
    btnLeft.style.display = tabMenu.scrollWidth >= window.innerWidth ? "" : "none";
}

window.onresize = function () {
    btnRight.style.display = tabMenu.scrollWidth > tabMenu.clientWidth || tabMenu.scrollWidth >= window.innerWidth ? "block" : "none";
    btnLeft.style.display = tabMenu.scrollWidth >= window.innerWidth ? "" : "none";

    let scrollLeftValue = Math(tabMenu.scrollLeft);

    btnLeft.style.display = scrollLeftValue > 0 ? "block" : "none";
}

let activeDrag = false;

tabMenu.addEventListener("mousemove", (drag) => {
    if (!activeDrag) return;
    tabMenu.scrollLeft -= drag.movementX;
    IconVisibility();
    tabMenu.classList.add("dragging");
});

document.addEventListener("mouseup", () => {
    activeDrag = false;
    tabMenu.classList.remove("dragging");
});

tabMenu.addEventListener("mousedown", () => {
    activeDrag = true;
});

//view tabs 

const tabs = document.querySelectorAll(".tab");
const tabBtns = document.querySelectorAll(".tab-btn");

const tab_Nav = function(tabBtnClick) {
    tabBtns.forEach((tabBtn) => {
        tabBtn.classList.remove("active");
    });

    tabs.forEach((tab) => {
        tab.classList.remove("active");
    });

    tabBtns[tabBtnClick].classList.add("active");
    tabs[tabBtnClick].classList.add("active");
}

tabBtns.forEach((tabBtn, i) => {
    tabBtn.addEventListener("click", () => {
        tab_Nav(i);
    });
});

//litters 
if (document.querySelector('#litters .methodslist')) {
  document.querySelectorAll('#litters .methodslist .icon-help').forEach((item) => {
      item.addEventListener('click', (icon) => {
          const methodbox = icon.target.parentNode;
          const detailsbox = methodbox.querySelector('.details');
          const iconHelp = methodbox.querySelector('.icon-help');

          if (!methodbox.classList.contains('open')) {
              if (document.querySelector('#litters .method.open')) {
                  sectionSlideUp(document.querySelector('#litters .methodslist .method.open .details'));
                  document.querySelector('#litters .method.open').classList.remove('open');
                  document.querySelectorAll('#litters .methodslist .icon-help.rotated').forEach((rotatedIcon) => {
                      rotatedIcon.classList.remove('rotated');
                  });
              }
              setTimeout(() => {
                  methodbox.classList.add('open');
                  iconHelp.classList.add('rotated');
                  sectionSlideDown(detailsbox);
                  setTimeout(() => {
                      window.scrollTo({
                          "behavior": "smooth",
                          "left": 0,
                          "top": methodbox.offsetTop + -85
                      });
                  }, 600);
              }, 0);
          } else {
              sectionSlideUp(detailsbox);
              methodbox.classList.remove('open');
              iconHelp.classList.remove('rotated');
          }
      });
  });
}

function sectionSlideDown(element)
{
	element.setAttribute('style', 'height:auto')
	let new_height = element.offsetHeight
	element.setAttribute('style', 'height:0')
	//timeout required for smooth effect
	setTimeout(()=>{
		element.setAttribute('style', 'height: auto')
	}, 5)
}
function sectionSlideUp(element)
{
	element.setAttribute('style', 'height:0')
}
// LITTERS 1 START
let slideIndex1 = 1;
showSlides1(slideIndex1);

function plusSlides1(n) {
  showSlides1(slideIndex1 += n);
}

function showSlides1(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides1");
  if (n > slides.length) {slideIndex1 = 1}    
  if (n < 1) {slideIndex1 = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slides[slideIndex1-1].style.display = "block";
}

// LITTERS 1 END
// LITTERS 2 START

let slideIndex2 = 1;
showSlides2(slideIndex2);

function plusSlides2(n) {
  showSlides2(slideIndex2 += n);
}

function showSlides2(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides2");
  if (n > slides.length) {slideIndex2 = 1}    
  if (n < 1) {slideIndex2 = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slides[slideIndex2-1].style.display = "block";
}
// LITTERS 2 END
// LITTERS 3 START
let slideIndex3 = 1;
showSlides3(slideIndex3);

function plusSlides3(n) {
  showSlides3(slideIndex3 += n);
}

function showSlides3(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides3");
  if (n > slides.length) {slideIndex3 = 1}    
  if (n < 1) {slideIndex3 = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slides[slideIndex3-1].style.display = "block";
}
// LITTERS 3 END
// LITTERS 4 START
let slideIndex4 = 1;
showSlides4(slideIndex4);

function plusSlides4(n) {
  showSlides4(slideIndex4 += n);
}

function showSlides4(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides4");
  if (n > slides.length) {slideIndex4 = 1}    
  if (n < 1) {slideIndex4 = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slides[slideIndex4-1].style.display = "block";
}